#!/bin/bash
export LC_CTYPE=UTF-8
CP=.:./lib

for jar in `ls lib/*.jar`
do
        CP=$CP:./$jar
done
for jar in `ls ../../lib/*.jar`
do
        CP=$CP:./$jar
done
for jar in `ls ../../system-bundles/boot/lib/*.jar`
do
        CP=$CP:./$jar
done
for jar in `ls ../../system-bundles/boot/thirdparty/*.jar`
do
        CP=$CP:./$jar
done

java -cp $CP com.liquidlabs.flow.simulation.SimpleJobSubmitter -master:stcp://localhost:22000/IceComputeGrid -work:computeGridSim.xml -stages:2 -lookup:stcp://localhost:11000 -useCache:true -partition:IceComputeGrid $@



