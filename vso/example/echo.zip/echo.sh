#!/bin/bash
while true
do
echo $@
sleep 5
done
