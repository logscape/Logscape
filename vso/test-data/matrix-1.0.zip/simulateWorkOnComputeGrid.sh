#!/bin/bash
export LC_CTYPE=UTF-8
CP=.:./lib

for jar in `ls lib/*.jar`
do
        CP=$CP:./$jar
done
for jar in `ls ../../lib/*.jar`
do
        CP=$CP:./$jar
done
for jar in `ls ../../third-party/*.jar`
do
        CP=$CP:./$jar
done

java -cp $CP com.liquidlabs.flow.simulation.ClientSubmitter -master:stcp://localhost:20000/MatrixComputeGrid -work:computeGridSim.xml 



